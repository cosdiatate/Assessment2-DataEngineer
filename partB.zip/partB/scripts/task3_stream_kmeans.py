from pyspark.sql import SparkSession
from pyspark.sql.functions import col, from_json
from pyspark.sql.types import StructType, StructField, StringType, DoubleType
from pyspark.ml.feature import VectorAssembler, StandardScaler
from pyspark.ml.clustering import KMeans

# 1) Create Spark session
spark = (
    SparkSession.builder
    .appName("Task3-Streaming-KMeans")
    .getOrCreate()
)

spark.sparkContext.setLogLevel("WARN")

# 2) Define schema of Kafka JSON messages (matches your producer)
schema = StructType([
    StructField("transaction_id", StringType(), True),
    StructField("customer_id", StringType(), True),
    StructField("amount", DoubleType(), True),
    StructField("currency", StringType(), True),
    StructField("timestamp_utc", StringType(), True),
    StructField("payment_method", StringType(), True),
    StructField("store", StringType(), True),
])

# 3) Read stream from Kafka topic
kafka_df = (
    spark.readStream
    .format("kafka")
    .option("kafka.bootstrap.servers", "kafka:9092")     # IMPORTANT: container-to-container
    .option("subscribe", "transactions_topic")
    .option("startingOffsets", "latest")
    .load()
)

# 4) Convert Kafka value bytes -> JSON -> columns
json_df = (
    kafka_df.selectExpr("CAST(value AS STRING) AS json")
    .select(from_json(col("json"), schema).alias("data"))
    .select("data.*")
)

# 5) Feature engineering: use amount as clustering feature
features_df = json_df.select("transaction_id", "customer_id", "amount", "store", "timestamp_utc") \
    .where(col("amount").isNotNull())

assembler = VectorAssembler(inputCols=["amount"], outputCol="vec")
final_df = assembler.transform(features_df)

# Optional scaling (helps KMeans stability)
scaler = StandardScaler(inputCol="vec", outputCol="features", withStd=True, withMean=True)
# We will fit scaler per micro-batch inside foreachBatch.

# 6) foreachBatch: fit KMeans on each micro-batch and assign cluster
def cluster_batch(batch_df, batch_id: int):
    if batch_df.rdd.isEmpty():
        return

    # Fit scaler on this batch
    scaler_model = scaler.fit(batch_df)
    scaled = scaler_model.transform(batch_df)

    # Fit KMeans on this batch (k=3 example)
    kmeans = KMeans(k=3, seed=42, featuresCol="features", predictionCol="cluster")
    model = kmeans.fit(scaled)

    clustered = model.transform(scaled).select(
        "transaction_id", "customer_id", "amount", "store", "timestamp_utc", "cluster"
    )

    print(f"\n===== Micro-batch {batch_id} (showing clusters) =====")
    clustered.show(20, truncate=False)

    # Save results for evidence (Parquet)
    clustered.write.mode("append").parquet("/tmp/task3_clusters_parquet")
    
query = (
    final_df.writeStream
        .foreachBatch(cluster_batch)   # <-- THIS is the key
        .outputMode("append")
        .option("checkpointLocation", "/tmp/checkpoints/task3_kmeans")
        .start()
)

query.awaitTermination()




